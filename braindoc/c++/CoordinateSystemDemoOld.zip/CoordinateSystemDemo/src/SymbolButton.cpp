#include "SymbolButton.h"

SymbolButton::SymbolButton() : ToggleButton(String::empty)
{
 setSize(16, 16);
 symbolIndex = 0;
}

SymbolButton::~SymbolButton(void)
{

}

void SymbolButton::setSymbolIndex(int newSymbolIndex)
{
 symbolIndex = newSymbolIndex;
}


void SymbolButton::paintButton(Graphics &g, bool isMouseOverButton, 
                               bool isButtonDown)
{
 ToggleButton::paintButton(g, isMouseOverButton, isButtonDown);

 float x1, x2;
 float y1, y2;
 switch( symbolIndex )
 {
 case PLUS:
  {
   x1 = 0.5f*getWidth();
   x2 = x1;
   y1 = getHeight()-4.f;
   y2 = 4.f;
   g.drawLine(x1, y1, x2, y2, 2.f);

   x1 = 4.f;
   x2 = getWidth()-4.f;
   y1 = 0.5f*(getHeight());
   y2 = y1;
   g.drawLine(x1, y1, x2, y2, 2.f);
  }
  break;
 case MINUS:
  {
   x1 = 4.f;
   x2 = getWidth()-4.f;
   y1 = 0.5f*(getHeight());
   y2 = y1;
   g.drawLine(x1, y1, x2, y2, 2.f);
  }
  break;


 }

}