/**

This class demonstrates the functions of the Coordinatesystem class.

*/

#ifndef __JUCE_COORDINATESYSREMDEMOCONTENTCOMPONENT_JUCEHEADER__
#define __JUCE_COORDINATESYSREMDEMOCONTENTCOMPONENT_JUCEHEADER__

#include "CoordinateSystem.h"

class CoordinateSystemDemoContentComponent : public Component,
                                             public ChangeBroadcaster,
                                             public ButtonListener,
                                             public ComboBoxListener,
                                             public LabelListener
{  

public:

 CoordinateSystemDemoContentComponent(const String &newEditorName);  
 ///< Constructor.

 virtual ~CoordinateSystemDemoContentComponent();                             
 ///< Destructor.

 virtual void buttonClicked(Button *buttonThatWasClicked);
 /**< Implements the purely virtual buttonClicked()-method of the 
      ButtonListener base-class. */

 virtual void comboBoxChanged(ComboBox *comboBoxThatHasChanged);
 /**< Implements the purely virtual comboBoxChanged()-method of the 
      ComboBoxListener base-class. */

 virtual void labelTextChanged(Label *labelThatHasChanged); 
 /**< Implements the purely virtual labelTextChanged()-method of the 
      LablelListener base-class. */
 
 virtual void setBounds(int x, int y, int width, int height);
 /**< Overrides the setBounds()-method of the Component base-class in order
      to arrange the widgets according to the size. */

protected:

 CoordinateSystem* theCoordinateSystem;

 Label*            xAxisSetupLabel;
 Label*            xAnnotationLabel;
 Label*            xAnnotationEditLabel;
 Label*            minXLabel;
 Label*            minXEditLabel;
 Label*            maxXLabel;
 Label*            maxXEditLabel;
 ToggleButton*     logScaleXButton;
 ComboBox*         xAxisComboBox;

 Label*            yAxisSetupLabel;
 Label*            yAnnotationLabel;
 Label*            yAnnotationEditLabel;
 Label*            minYLabel;
 Label*            minYEditLabel;
 Label*            maxYLabel;
 Label*            maxYEditLabel;
 ToggleButton*     logScaleYButton;
 ComboBox*         yAxisComboBox;

 Label*            gridSetupLabel;

 Label*            horizontalGridSetupLabel;
 ToggleButton*     horizontalCoarseGridButton;
 Label*            horizontalCoarseGridIntervalLabel;
 ToggleButton*     horizontalFineGridButton;
 Label*            horizontalFineGridIntervalLabel;

 Label*            verticalGridSetupLabel;
 ToggleButton*     verticalCoarseGridButton;
 Label*            verticalCoarseGridIntervalLabel;
 ToggleButton*     verticalFineGridButton;
 Label*            verticalFineGridIntervalLabel;

 Label*            radialGridSetupLabel;
 ToggleButton*     radialCoarseGridButton;
 Label*            radialCoarseGridIntervalLabel;
 ToggleButton*     radialFineGridButton;
 Label*            radialFineGridIntervalLabel;

 Label*            angularGridSetupLabel;
 ToggleButton*     angularCoarseGridButton;
 Label*            angularCoarseGridIntervalLabel;
 ToggleButton*     angularFineGridButton;
 Label*            angularFineGridIntervalLabel;
};

#endif  // end of #ifndef __JUCE_COORDINATESYSREMDEMOCONTENTCOMPONENT_JUCEHEADER__