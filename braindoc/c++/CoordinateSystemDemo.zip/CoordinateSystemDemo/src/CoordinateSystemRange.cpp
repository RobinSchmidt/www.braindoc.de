#include "CoordinateSystemRange.h"

CoordinateSystemRange::CoordinateSystemRange(double initMinX, double initMaxX,
                                             double initMinY, double initMaxY)
 {
  minX = -2.2;
  maxX = +2.2;
  minY = -2.2;
  maxY = +2.2;
 }

CoordinateSystemRange::~CoordinateSystemRange()
{

}

void CoordinateSystemRange::setMinX(double newMinX) 
{ 
 jassert( newMinX < maxX )
 if( newMinX < maxX )
  minX = newMinX;
}

void CoordinateSystemRange::setMaxX(double newMaxX) 
{ 
 jassert( newMaxX > minX )
 if( newMaxX > minX )
  maxX = newMaxX;
}

void CoordinateSystemRange::setMinY(double newMinY) 
{ 
 jassert( newMinY < maxY )
 if( newMinY < maxY )
  minY = newMinY;
}

void CoordinateSystemRange::setMaxY(double newMaxY) 
{ 
 jassert( newMaxY > minY )
 if( newMaxY > minY )
  maxY = newMaxY;
}



