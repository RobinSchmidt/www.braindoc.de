/**

This class represents the visible range for a CoordinateSystem (and is used 
inside this class).

*/

#ifndef __JUCE_COORDINATESYSTEMRANGE_JUCEHEADER__
#define __JUCE_COORDINATESYSTEMRANGE_JUCEHEADER__

#include <juce.h>

class CoordinateSystemRange
{

public:

 /** Standard Constructor. */
 CoordinateSystemRange(double initMinX = -2.2, double initMaxX = +2.2,
                       double initMinY = -2.2, double initMaxY = +2.2);

 /** Destructor. */
 virtual ~CoordinateSystemRange();  

 /** Returns the minimum x-value. */
 virtual double getMinX() const { return minX; }

 /** Returns the maximum x-value. */
 virtual double getMaxX() const { return maxX; }

 /** Returns the minimum y-value. */
 virtual double getMinY() const { return minY; }

 /** Returns the maximum y-value. */
 virtual double getMaxY() const { return maxY; }

 /** Sets the minimum x-value. */
 virtual void setMinX(double newMinX);

 /** Sets the maximum x-value. */
 virtual void setMaxX(double newMaxX);

 /** Sets the minimum y-value. */
 virtual void setMinY(double newMinY);

 /** Sets the maximum y-value. */
 virtual void setMaxY(double newMaxY); 

protected:

 double minX, maxX, minY, maxY;
};

#endif  // __JUCE_COORDINATESYSTEMRANGE_JUCEHEADER__
