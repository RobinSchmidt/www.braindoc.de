#include "HelperFunctions.h"

double logB(double x, double b)
{
 return log(x)/log(b);
}

double round(double x)
{
 if( x-floor(x) >= 0.5 )
  return ceil(x);
 else
  return floor(x);
}