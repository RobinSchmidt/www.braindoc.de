#ifndef __JUCE_SYMBOLBUTTON_JUCEHEADER__
#define __JUCE_SYMBOLBUTTON_JUCEHEADER__

#include <juce.h>

class SymbolButton : public ToggleButton
{
public:

 enum buttonSymbols
 {
  NO_SYMBOL = 0,
  PLUS,
  MINUS,
  MUTE,
  LOOP
 };

          SymbolButton();   /**< Constructor. */
 virtual ~SymbolButton();   /**< Destructor. */

 virtual void setSymbolIndex(int newSymbolIndex);

 virtual void paintButton(Graphics &g, 
                          bool isMouseOverButton, 
                          bool isButtonDown);
  /**< Overrides the paint-method of the ToggleButton base-class. */

protected:

 int symbolIndex;
};

#endif   // __JUCE_SYMBOLBUTTON_JUCEHEADER__