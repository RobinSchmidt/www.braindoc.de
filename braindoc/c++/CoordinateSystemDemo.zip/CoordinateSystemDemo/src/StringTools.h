#ifndef __JUCE_STRINGTOOLS_JUCEHEADER__
#define __JUCE_STRINGTOOLS_JUCEHEADER__

#include <juce.h>
#include "HelperFunctions.h"

//#include "../../../third_party_code/juce/juce.h"
//#include "../../rosic/basics/rosic_MoreMath.h"

String midiNoteToString(double midiNoteNumber);
/**< Converts a midi-note number into a juce-string.  */

String decibelsToStringWithUnit1(double value);
/**< Converts a decibel-value into a juce-string with 1 digit
     after the point and adds the unit-suffix "dB".  */

String decibelsToStringWithUnit2(double value);
/**< Converts a decibel-value into a juce-string with 2 digits
     after the point and adds the unit-suffix "dB".  */

String hertzToStringWithUnitTotal5(double value);
/**< Converts a decibel-value into a juce-string with 5 digits in total
     adds the unit-suffix "Hz".  */

String percentToStringWithUnit0(double value);
/**< Converts a percent-value into a juce-string without decimal digits
     after the point and adds the unit-suffix "%".  */

String percentToStringWithUnit1(double value);
/**< Converts a percent-value into a juce-string with one decimal digit
     after the point and adds the unit-suffix "%".  */

String ratioToString0(double value);
/**< Converts a ratio into a juce-string without decimal digits. */

String semitonesToStringWithUnit2(double value);
/**< Converts a semitone-value into a juce-string with 2 digits
     after the point and adds the unit-suffix "st".  */

String secondsToStringWithUnit3(double value);
/**< Converts a time-value in seconds into a juce-string with 3 digits
     after the point and adds the unit-suffix "s".  */

String secondsToStringWithUnit4(double value);
/**< Converts a time-value in seconds into a juce-string with 4 digits
     after the point and adds the unit-suffix "s".  */

String secondsToStringWithUnitTotal4(double value);
/**< Converts a time-value in seconds into a juce-string with  a total number
     of 4 digits the unit-suffix "s" or "ms".  */

String valueToStringWithTotalNumDigits(double value, int totalNumDigits = 3, 
                                       const String& suffix = String::empty);
/**< Converts a value into a juce-string with adjustable total number of 
     decimal digits and an optional suffix.  */

String valueToString0(double value);
/**< Converts a value into a juce-string without decimal digits after the 
     point.  */

String valueToString1(double value);
/**< Converts a value into a juce-string with 1 decimal digit after the 
     point.  */

String valueToString2(double value);
/**< Converts a value into a juce-string with 2 decimal digits after the 
     point.  */

String valueToString3(double value);
/**< Converts a value into a juce-string with 2 decimal digits after the 
     point.  */

String valueToString4(double value);
/**< Converts a value into a juce-string with 2 decimal digits after the 
     point.  */

String valueToStringTotal5(double value);
/**< Converts a value into a juce-string with 5 decimal digits in total.  */

#endif   // __JUCE_STRINGTOOLS_JUCEHEADER__