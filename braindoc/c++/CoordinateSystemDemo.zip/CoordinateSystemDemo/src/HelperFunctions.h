/**
This header-file defines some useful functions.
*/

#ifndef __JUCE_HELPERFUNCTIONS_JUCEHEADER__
#define __JUCE_HELPERFUNCTIONS_JUCEHEADER__

#define _USE_MATH_DEFINES
#include <math.h>

double logB(double x, double b);
///< Calculates logarithm to an arbitrary base b.

template <class T>
T max(T in1, T in2)
{
 if( in1 > in2 )
  return in1;
 else
  return in2;
}
/**< The maximum of two objects on which the ">"-operator is defined. */
// ...seems that templates must be defined in the header to make it work

double round(double x);
///< Returns the nearest integer (returns value still as double).

#endif // __JUCE_HELPERFUNCTIONS_JUCEHEADER__