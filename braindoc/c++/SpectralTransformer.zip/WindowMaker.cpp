// WindowMaker.cpp: implementation of the WindowMaker class.
//
//////////////////////////////////////////////////////////////////////

#include "WindowMaker.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

WindowMaker::WindowMaker()
{

}

WindowMaker::~WindowMaker()
{

}

//-----------------------------------------------------------------------------
//window generation:
void WindowMaker::getRectangularWindow(sample *Buffer, long Length)
{
 for(long i=0; i<Length; i++)
  Buffer[i]  = 1.0;
}

//not really e�xact - improve later:
void WindowMaker::getTriangularWindow(sample *Buffer, long Length)
{
 Buffer[0] = 0;
 for(long i=1; i<=(Length/2); i++)
  Buffer[i] = Buffer[i-1] + 1;

 for(i=(Length/2)+1; i<Length; i++)
  Buffer[i] = Buffer[i-1] - 1;

 //the maximum value of the window is now delay/2
 //normalize it to one:
 for(i=0; i<Length; i++) 
  Buffer[i] = (2*Buffer[i])/Length;
}

void WindowMaker::getCosSquaredWindow(sample *Buffer, long Length)
{
 for(long i=0; i<Length; i++)
 {
  Buffer[i]  = sin( (PI/Length) * i); //a sine with period (2*Length)
  Buffer[i] *= Buffer[i];             //square the sine
 }
}
