/* 

SpectralTransformer.h: interface for the SpectralTransformer class.

� Braindoc 2005 (www.braindoc.de)

This is an audio module which modulates the panorama of an incoming audio signal via a LFO.

*/


#if !defined(SpectralTransformer_h_Included)
#define SpectralTransformer_h_Included

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "stdlib.h"
#include "math.h"
#include "VSTools.h"
#include "FFTAnalyzeResynthesize.h"

class SpectralTransformer  
{
public:
	//construction/destruction:
	SpectralTransformer();
	virtual ~SpectralTransformer();

	//public member functions:
	//parameter settings:
	void setSampleRate   (sample Samplerate);  //set the sample rate
 void setWindow       (long   Window);
 void setOverlapWindow(long   OverlapWindow);
 void setBlockSize    (long   BlockSize);

 void setContrastL    (sample ContrastL);
 void setContrastR    (sample ContrastR);
 void setMagMixL      (sample MagMixL);
 void setMagMixR      (sample MagMixR);
 void setPhsMixL      (sample PhsMixL);
 void setPhsMixR      (sample PhsMixR);


	//audio processing:
	void getSamples  (float *InSampL, float *InSampR, float *OutSampL, float *OutSampR);   
	//calculates the output-samples for both channels and stores them at the adresses of *OutsampL
	//and OutSamp* - the user has to call this function with the adresses of the two input-samples
	//to be processed and the adresses where the processed samples shpuld be stored in

protected:
 //embedded audio-modules:
 FFTAnalyzeResynthesize anaAndResynthL, anaAndResynthR;

	//parameters:
	sample sampleRate;
 long   blockSize;
 sample contrastL, contrastR;
 sample magMixL, magMixR, phsMixL, phsMixR;

};

#endif // !defined(SpectralTransformer_h_Included)
