#include <stdio.h>
#include <math.h>

//--------------------------------------------------------------------------------------------------
//functions for conversion from float-vst-parameter to string:
void dB2String(float value, char* string)
{
	double mappedValue = value*96-48; //maps the value (from 0 to 1) to +- 48
 sprintf(string,       //pointer where the string is to be stored 
        "%.1f %s",     //format string, indicates that the first parameter (after the
                       //format parameters) will be a double/float type parameter 
                       //and should be runded to 1 digit and the second one will be a
                       //string type parameter
        mappedValue,   //the parameter of type double/float
        " dB");        //the parameter of type string (the " dB" string in this case)
}


void percent2String(float value, char* string)
{
 double mappedValue = 100*value;
 sprintf(string,     
        "%.1f %s",mappedValue,"%");       
}


void phase2String(float value, char* string)
{
 double mappedValue = 360*value;
 sprintf(string,     
        "%.1f %s",mappedValue,"�");       
}

void lpf2String(float value, char* string)
{
 double mappedValue = 0.1*pow(10000,value); //from 0.1 to 1000 Hz
 sprintf(string, "%.2f", mappedValue);
}

void hpf2String(float value, char* string)
{
 double mappedValue = 0.1*pow(10000,value) - 0.1; //from 0.0 to 999.9 Hz
 sprintf(string, "%.2f", mappedValue);
}


//takes an index for a note-length and returns an appropriate string:
void lengthIndex2String(float value, char* string)
{
 long lengthIndex = (long) value;

 switch(lengthIndex)
 {
  case  1:  sprintf(string, "%s" ,"1/128");      break;
  case  2:  sprintf(string, "%s" ,"1/96");       break;
  case  3:  sprintf(string, "%s" ,"3/256");      break;
  case  4:  sprintf(string, "%s" ,"1/64");       break;
  case  5:  sprintf(string, "%s" ,"1/48");       break;
  case  6:  sprintf(string, "%s" ,"3/128");      break;
  case  7:  sprintf(string, "%s" ,"1/32");       break;
  case  8:  sprintf(string, "%s" ,"1/24");       break;
  case  9:  sprintf(string, "%s" ,"3/64");       break;
  case 10:  sprintf(string, "%s" ,"1/16");       break;
  case 11:  sprintf(string, "%s" ,"1/12");       break;
  case 12:  sprintf(string, "%s" ,"3/32");       break;
  case 13:  sprintf(string, "%s" ,"1/8");        break;
  case 14:  sprintf(string, "%s" ,"1/6");        break;
  case 15:  sprintf(string, "%s" ,"3/16");       break;
  case 16:  sprintf(string, "%s" ,"1/4");        break;
  case 17:  sprintf(string, "%s" ,"1/3");        break;
  case 18:  sprintf(string, "%s" ,"3/8");        break;
  case 19:  sprintf(string, "%s" ,"1/2");        break;
  case 20:  sprintf(string, "%s" ,"2/3");        break;
  case 21:  sprintf(string, "%s" ,"3/4");        break;
  case 22:  sprintf(string, "%s" ,"1");          break;
  case 23:  sprintf(string, "%s" ,"4/3");        break;
  case 24:  sprintf(string, "%s" ,"3/2");        break;
  case 25:  sprintf(string, "%s" ,"2");          break;
  case 26:  sprintf(string, "%s" ,"3");          break;
  case 27:  sprintf(string, "%s" ,"4");          break;
  case 28:  sprintf(string, "%s" ,"6");          break;
  case 29:  sprintf(string, "%s" ,"8");          break;
  case 30:  sprintf(string, "%s" ,"12");         break;
  case 31:  sprintf(string, "%s" ,"16");         break;
  case 32:  sprintf(string, "%s" ,"24");         break;
  case 33:  sprintf(string, "%s" ,"32");         break;
 }
}

