/* 

FFTransformer.h: interface for the FFTransformer class.

� Braindoc 2006 (www.braindoc.de)

This class is built aroung the free FFT-routine in fft4g.c
....blah blah blah still to come
It is designed to be easy to use, in that it shields the user from the underlying
complex arithmetic (and the resulting interleaved buffer-represantation of complex
numbers), from the inherent redundancies of the DFT of real signals and normalization
issues.

*/

#if !defined(FFTransformer_h_Included)
#define FFTransformer_h_Included

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAXBLOCKSIZE 8192    //maximum FFT-Size
#define BITREVWORKSIZE 2048  //size of the working area for bit reversal, has to
                             //be defined as >=2+sqrt(MAXBLOCKSIZE/4) !!!

#include <stdio.h> //for debugging

class FFTransformer  
{

public:

 //construction/destruction
	FFTransformer();
	virtual ~FFTransformer();

 //parameter settings:
 void setBlockSize(int BlockSize);

 //forward FFT's:
 void getReAndImFromSig  (double *Sig, double *ReAndIm);   
  //calculates real and imaginary part of the spectrum as interleaved
  //double buffer: buf[2]=re[1], buf[3]=im[1], buf[4]=re[2], buf[5]=im[2],...
  //in general: buf[2*k]=re[k], buf[2k+1]=im[k], k=1,..,(n/2)-1 where n is the
  //FFT-size. the first two elements of the buffer have a special meaning:
  //buf[0] is the (purely real) DC and buf[1] is the (purely real) coefficient
  //for the Nyquist frequency. the other fields contain the  real and imaginary 
  //parts of the positive frequencies only (interleaved) as the negative 
  //frequencies are redundant (conjugate symmetric). to compensate for the 
  //energy loss while discarding the negative frequencies, the positive
  //frequencies are multiplied by a factor of 2

 void getMagAndPhsFromSig(double *Sig, double *Mag, double *Phs);
  //calculates magnitude and phase from a signal, *Sig is of length n, 
  //*Mag and *Phs are of length n/2:

 void getMagFromSig      (double *Sig, double *Mag);
  //calculates magnitude only from a signal (for analyzer-stuff):


 //inverse FFT's:
 void getSigFromReAndIm  (double *ReAndIm, double *Sig);
  //calculates a time signal from and interleaved buffer containing the
  //real and imaginary parts of the positive frequencies (the negative
  //frequencies are conjugate symmetric)

 void getSigFromMagAndPhs(double *Mag, double *Phs, double *Sig);
  //calculates a time signal from its magnitudes and phases, *Mag and *Phs
  //are of length n/2, *Sig is of length n



private:

 double complexBuf[2*MAXBLOCKSIZE];  //internal buffer for the in-place
                                     //calculation of the FFT, twice as
                                     //long as the (maximum) FFT-size, because
                                     //it holds complex numbers (as interleaved
                                     //re/im representation)

 int    blockSize;             //the actual FFT-size, has to be a power of 2

 double blockSizeRec;          //reciprocal of the blocksize - has to be used as
                               //scale factor for the inverse FFT

 int    ip[BITREVWORKSIZE];    //working area for bit reversal, ip[0]=0 indicates,
                               //that the table of twiddle factors has to be
                               //recalculated

 double w[MAXBLOCKSIZE];       //table of the twiddle factors - will be calculated
                               //before the actual FFT if ip[0]=0
                               //...can be shrinked to >= (MAXBLOCKSIZE*5)/8-1

};

#endif // !defined(FFTransformer_h_Included)
