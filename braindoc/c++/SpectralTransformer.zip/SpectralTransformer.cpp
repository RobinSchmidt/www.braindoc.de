#include "SpectralTransformer.h"

//construction/destruction
SpectralTransformer::SpectralTransformer()
{
 //init member variables:
 sampleRate         = 44100.0;   
}

SpectralTransformer::~SpectralTransformer()
{
 
}
//---------------------------------------------------------------------------------------
//parameter settings:
void SpectralTransformer::setSampleRate(sample SampleRate)
{
 if(SampleRate>0)
  sampleRate = SampleRate;
}

void SpectralTransformer::setWindow(long Window)
{
 anaAndResynthL.setAnalysisWindow(Window);
 anaAndResynthR.setAnalysisWindow(Window);
}

void SpectralTransformer::setOverlapWindow(long OverlapWindow)
{
 anaAndResynthL.setReconstructWindow(OverlapWindow);
 anaAndResynthR.setReconstructWindow(OverlapWindow);
}

void SpectralTransformer::setBlockSize(long BlockSize)
{
 blockSize = BlockSize;
 anaAndResynthL.setBlockSize(blockSize);
 anaAndResynthR.setBlockSize(blockSize);
}

void SpectralTransformer::setContrastL(sample ContrastL)
{
 contrastL = ContrastL;
}

void SpectralTransformer::setContrastR(sample ContrastR)
{
 contrastR = ContrastR;
}

void SpectralTransformer::setMagMixL(sample MagMixL)
{
 magMixL = MagMixL;
}

void SpectralTransformer::setMagMixR(sample MagMixR)
{
 magMixR = MagMixR;
}

void SpectralTransformer::setPhsMixL(sample PhsMixL)
{
 phsMixL = PhsMixL;
}

void SpectralTransformer::setPhsMixR(sample PhsMixR)
{
 phsMixR = PhsMixR;
}




//---------------------------------------------------------------------------------------
//audio processing:
void SpectralTransformer::getSamples  (float *InSampL, float *InSampR, float *OutSampL, float *OutSampR)
{
 static sample inL,       inR;        //parameters are pointers to float whereas the internal
	static sample outL,      outR;       //the output samples
 static float  outFloatL, outFloatR;  //typecasted versions of output samples
 static long   i;                     //for the loop through the spectrum
 static sample inEnergyL, inEnergyR;
 static sample outEnergyL, outEnergyR;
 static sample factorL, factorR, factor;
 static sample tmpMagL, tmpMagR, tmpPhsL, tmpPhsR, tmp;

	//cast the incoming float-samples to double precision for internal
	//signal processing:
	inL = (sample) *InSampL;
 inR = (sample) *InSampR;

 //do the signal processing:
 outL = anaAndResynthL.getSample(inL);
 outR = anaAndResynthR.getSample(inR);

 //check, if a new spectrum has to be processed:
 if(anaAndResynthL.spectrumReadyToProcess)
 {
  //calculate total energy (magnitude squared) of input:
  inEnergyL = 0;
  inEnergyR = 0;
  for(i=1; i<(blockSize/2); i++)
  {
   inEnergyL += anaAndResynthL.magBuf[i];// * anaAndResynthL.magBuf[i];
   inEnergyR += anaAndResynthR.magBuf[i];// * anaAndResynthR.magBuf[i];
  }

  //apply effects to the spectrum (both channels):
  //contrast:
  for(i=1; i<(blockSize/2); i++)
  {
   anaAndResynthL.magBuf[i] = pow(anaAndResynthL.magBuf[i], contrastL);
   anaAndResynthR.magBuf[i] = pow(anaAndResynthR.magBuf[i], contrastR);
  }

  //spectral crossfade:
  for(i=1; i<(blockSize/2); i++)
  {
   tmpMagL = anaAndResynthL.magBuf[i];
   tmpMagR = anaAndResynthR.magBuf[i]; 
   tmpPhsL = anaAndResynthL.phsBuf[i];
   tmpPhsR = anaAndResynthR.phsBuf[i]; 

   //calculate and set magnitude and phases for both channels:
   anaAndResynthL.magBuf[i] = (1-magMixL)*tmpMagL + magMixL*tmpMagR;
   anaAndResynthR.magBuf[i] = (1-magMixR)*tmpMagL + magMixR*tmpMagR;
   anaAndResynthL.phsBuf[i] = (1-phsMixL)*tmpPhsL + phsMixL*tmpPhsR;
   anaAndResynthR.phsBuf[i] = (1-phsMixR)*tmpPhsL + phsMixR*tmpPhsR;

   //for test: multiply both spectra:
   //anaAndResynthL.magBuf[i] = tmpMagL * tmpMagR;
   //anaAndResynthR.magBuf[i] = tmpMagL * tmpMagR;
  }

  //calculate total energy (magnitude squared) of output:
  outEnergyL = 0;
  outEnergyR = 0;
  for(i=1; i<(blockSize/2); i++)
  {
   outEnergyL += anaAndResynthL.magBuf[i];// * anaAndResynthL.magBuf[i];
   outEnergyR += anaAndResynthR.magBuf[i];// * anaAndResynthR.magBuf[i];
  }

  //calculate normalization-factors for both channels:
  factorL = inEnergyL/outEnergyL;
  factorR = inEnergyR/outEnergyR;
  //factorL = outEnergyL/inEnergyL;
  //factorR = outEnergyR/inEnergyR;
  //factor = 0.5*(factorL+factorR);

  //normalize:
  for(i=1; i<(blockSize/2); i++)
  {
   anaAndResynthL.magBuf[i] *= factorL;
   anaAndResynthR.magBuf[i] *= factorR;
  }

  //set DC and Nyquist to zero:
  //anaAndResynthL.magBuf[0] = 0;
  //anaAndResynthR.magBuf[0] = 0;
  //anaAndResynthL.phsBuf[0] = 0;
  //anaAndResynthR.phsBuf[0] = 0;
 }



	//typecast the double values to float values to make them compatible with the pointers
	//in the parameters:
	outFloatL = (float) outL;
	outFloatR = (float) outR;

 //put the output-samples into the slots, where the calling funtion wants them to be stored
	*OutSampL = outFloatL;
	*OutSampR = outFloatR;

	return;
}

//---------------------------------------------------------------------------------------
//others:

