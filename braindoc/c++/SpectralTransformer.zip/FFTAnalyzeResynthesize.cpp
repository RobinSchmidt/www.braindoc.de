// FFTAnalyzeResynthesize.cpp: implementation of the FFTAnalyzeResynthesize class.
//
//////////////////////////////////////////////////////////////////////

#include "FFTAnalyzeResynthesize.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

FFTAnalyzeResynthesize::FFTAnalyzeResynthesize()
{
 anaWndIndex   = 2;
 recWndIndex   = 2;
 blockSize     = 1024;
 halfBlockSize = blockSize/2;
 fftSize       = 1024;

 cnt           = 0;

 //generate the windows:
 windowMaker.getCosSquaredWindow(w, blockSize);
 windowMaker.getCosSquaredWindow(v, blockSize);

 trafo.setBlockSize(fftSize);
}

FFTAnalyzeResynthesize::~FFTAnalyzeResynthesize()
{

}

//-----------------------------------------------------------------------------
//parameter settings:
void FFTAnalyzeResynthesize::setBlockSize(long BlockSize)
{
 //still to do: chech if is a power of two and <= MAXBLOCKSIZE
 blockSize     = BlockSize;
 halfBlockSize = blockSize/2;

 fftSize       = blockSize;

 //reset the sample-counter
 cnt           = 0;

 //generate the windows:
 setAnalysisWindow(anaWndIndex);
 setReconstructWindow(recWndIndex);

 trafo.setBlockSize(fftSize);
}

void FFTAnalyzeResynthesize::setAnalysisWindow(long AnalysisWindow)
{
 anaWndIndex = AnalysisWindow;

 switch(anaWndIndex)
 {
  case 0:  windowMaker.getRectangularWindow(w, blockSize); break;
  case 1:  windowMaker.getTriangularWindow(w, blockSize);  break;
  case 2:  windowMaker.getCosSquaredWindow(w, blockSize);  break;

  default: windowMaker.getRectangularWindow(w, blockSize);
 }
}

void FFTAnalyzeResynthesize::setReconstructWindow(long ReconstructWindow)
{
 recWndIndex = ReconstructWindow;

 switch(recWndIndex)
 {
  case 0:  windowMaker.getRectangularWindow(v, blockSize); break;
  case 1:  windowMaker.getTriangularWindow(v, blockSize);  break;
  case 2:  windowMaker.getCosSquaredWindow(v, blockSize);  break;

  default: windowMaker.getRectangularWindow(v, blockSize);
 }
}






//-----------------------------------------------------------------------------
//signal processing:
void FFTAnalyzeResynthesize::applyAnalysisWindow(sample *Buffer)
{
 for(long i=0; i<blockSize; i++)
  Buffer[i] *= w[i];
}
