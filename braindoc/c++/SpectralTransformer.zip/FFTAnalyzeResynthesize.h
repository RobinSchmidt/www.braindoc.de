/* 

FFTAnalyzeResynthesize.h: interface for the FFTAnalyzeResynthesize class.

� Braindoc 2006 (www.braindoc.de)

This class encapsulates all the buffering, windowing, and overlap/add stuff which
is associated with FFT based effects. It provides the user of this class with a
sample-by-sample input/output function (as always: getSample()) and from time to
time it sets a flag, to indicate, that a new spectrum is ready to be processed by 
the outlying class. when the oulying class does nothing with the spectrum, the output 
signal will be equal to the input signal.
(apart from some artifacts introduced by windowing and overlapp/add).

*/

#if !defined(FFTAnalyzeResynthesize_h_Included)
#define FFTAnalyzeResynthesize_h_Included

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "VSTools.h"
#include "WindowMaker.h"
#include "FFTransformer.h"

class FFTAnalyzeResynthesize  
{
public:
 //construction/destruction:
 FFTAnalyzeResynthesize();
 virtual ~FFTAnalyzeResynthesize();

 //parameter settings:
 void setAnalysisWindow   (long AnalysisWindow);    //the window to be apllied to the input 
                                                    //before it is transfromed
 void setReconstructWindow(long ReconstructWindow); //the window to be applied to the outputs
                                                    //before they are added
 void setBlockSize        (long BlockSize);         //the blocksize
 /*
 void setFFTSize          (long FftSize);           //has not necesarrily to be the same as the
                                                    //blocksize - can be larger (->zero padding)
 //when fftSize>Blocksize, the output and input signal buffers will have different
 //lengths - implement this later, when everything else works fine....

  */

 //audio processing:
 __forceinline sample getSample(sample In);

 //info-flag for the outlying class:
 bool spectrumReadyToProcess;

 //buffer for the spectrum (magnitude and phase seperate) - shall
 //be processed by the outlying class whenever the flag above is true
 //(therefore pulic):
 sample magBuf[MAXBLOCKSIZE/2];
 sample phsBuf[MAXBLOCKSIZE/2];

private:
 //embedded objects:
 FFTransformer trafo;
 WindowMaker   windowMaker;

 //parameter variables:
 long anaWndIndex;   //index of the analysis window
 long recWndIndex;   //index of the reconstruction window
 long blockSize;     //number of samples in one block of data
 long halfBlockSize; 
 long fftSize;       //for the moment: equal to blockSize

 long cnt;         //counts the calls of getSample mod blockSize 
                   // - that is: the counter reset whenever a "new
                   //block" of samples begins
 
 //2 buffers for the input-signal:
 sample inBuf1[MAXBLOCKSIZE];
 sample inBuf2[MAXBLOCKSIZE];

 //2 buffers for the output-signal:
 sample outBuf1[MAXBLOCKSIZE];
 sample outBuf2[MAXBLOCKSIZE];

 //buffers for the analysis- and reconstruction-window:
 sample w[MAXBLOCKSIZE];  //analysis-window
 sample v[MAXBLOCKSIZE];  //reconstruction-window

 //internal functions:
 void applyAnalysisWindow(sample *Buffer);
};

//-----------------------------------------------------------------------------
//from here: definitions of the functions to be inlined, i.e. all functions
//which are supposed to be called at audio-rate (they can't be put into
//the .cpp file):
__forceinline sample FFTAnalyzeResynthesize::getSample(sample In)
{
 static sample out;
 static long   buf2Pos;  //current postion in buffer2 ( = (cnt+halfBlockSize)%blockSize )

 //reset the sample-counter to zero when it reaches the blockSize:
 cnt %= blockSize;

 //calculate the position in buffer 2 (the position in buffer 1 is equal to "cnt"):
 buf2Pos = (cnt+halfBlockSize)%blockSize;

 //if in the last call the "spectrumReadyToProcess"-flag was set, this means, that in 
 //this call a new (processed) sepctrum is available to be inverse transformed - into 
 //which output-buffer it should be written is again determined by the postion in the
 //2 buffers:
 if(cnt==1)
 {
  //inverse transform the spectral buffer into outBuf1:
  trafo.getSigFromMagAndPhs(magBuf, phsBuf, outBuf1);

  //set flag to zero:
  spectrumReadyToProcess = false;
 }
 else if(buf2Pos==1)
 {
  //inverse transform the spectral buffer into outBuf1:
  trafo.getSigFromMagAndPhs(magBuf, phsBuf, outBuf2);

  //set flag to zero:
  spectrumReadyToProcess = false;
 }

 //initialize flag:
 spectrumReadyToProcess = false; //unnecesarry?

 //check, if inBuf1 is full:
 if(cnt==0)
 {
  //apply analysis window to input buffer 1:
  applyAnalysisWindow(inBuf1);

  //transform the buffer:
  trafo.getMagAndPhsFromSig(inBuf1, magBuf, phsBuf);

  //set flag:
  spectrumReadyToProcess = true;
 }
 //check, if inbuf2 is full:
 else if(buf2Pos==0)
 {
  //apply analysis window to input buffer 2:
  applyAnalysisWindow(inBuf2);

  //transform the buffer:
  trafo.getMagAndPhsFromSig(inBuf2, magBuf, phsBuf);

  //set flag:
  spectrumReadyToProcess = true;
 }

 //buffer the incoming signal
 inBuf1[cnt]     = In;
 inBuf2[buf2Pos] = In;

 //generate the output by means of overlap-add:
 out = v[cnt]*outBuf1[cnt] + v[buf2Pos]*outBuf2[buf2Pos];

 //increment sample-counter:
 cnt++;

 return out;
}






#endif // !defined(FFTAnalyzeResynthesize_h_Included)
