/*-----------------------------------------------------------------------------

� Braindoc 2002 (www.braindoc.de)


-----------------------------------------------------------------------------*/

#include "SpectralTransformerVST.hpp"
#include "VSTools.h"
#include "math.h"

extern bool oome;  //is set to true, if editor can not be created (out of memory exception)

//-----------------------------------------------------------------------------
//constructor:

SpectralTransformerVST::SpectralTransformerVST(audioMasterCallback audioMaster)
	: AudioEffectX(audioMaster, kNumPrograms, kNumParams)
{
 //init programs:
 programs = new SpectralTransformerVSTProgram[kNumPrograms];
 //load presets into the programs:
 //loadPresets();
 //use the first program by default:
 if (programs)
  setProgram (0);

 //set the sampleRate for the SpectralTransformer-object (the audio processing module)
 spectralTransformer.setSampleRate(getSampleRate());

 //init the parameters via calls of setParameter (this also updates the
 //corresponding values in the actual audio processing module):
 /*
 setParameter(kLinMode,            0.0f); 
 setParameter(kWave,               0.0f); 
 setParameter(kPhase,              0.0f); 
 setParameter(kSpeed,              0.49f); 
 setParameter(kAmount,             0.0f); 
 setParameter(kLpf,                1.0f); 
 setParameter(kHpf,                0.0f); 
 */

	//tell host some features:
	setNumInputs(2);		                //stereo in
	setNumOutputs(2);		               //stereo out
	setUniqueID('rTpS');	             //identification of the plugIn, use exactly 4 characters
	canMono();				                    //it makes sense to feed both inputs with the same signal
	canProcessReplacing();	           //supports both accumulating and replacing output
	strcpy(programName, "Default");	  //default program name


 //if the following lines are commented we will get a PlugIn without GUI - only the
	//string-based standard interface will be available:
 //create the editor object:

 /*
 editor = new SpectralTransformerVSTEditor(this); //editor gets a pointer to the effect object,
                                          //which is to be edited
 if(!editor)
  oome = true;
  */


}

//-----------------------------------------------------------------------------------------
//destructor:
SpectralTransformerVST::~SpectralTransformerVST()
{
 //free dynamically allocated memory here:
	if (programs)   delete[] programs;

 //editor has not to be deleted here, because it is deleted by the AudioEffect base class
}
	
//-----------------------------------------------------------------------------------------
//this functions is called, when the hosts sample-rate has changed:
void SpectralTransformerVST::setSampleRate (float sampleRate)
{
 AudioEffectX::setSampleRate (sampleRate);
 //here you may want to update the sample-rate in your audio-module (essential for filters,
	//oscillators, etc, - unnecessary for waveshapers, etc.):
	spectralTransformer.setSampleRate(sampleRate);
}			
			
//-----------------------------------------------------------------------------------------
//allows the user to set the parameters (one at a time):
void SpectralTransformerVST::setParameter(long index, float value)  
{
	SpectralTransformerVSTProgram *ap = &programs[curProgram]; 
	//a pointer to the current program to update the values in the program object too
 double tmp;

	switch(index)
	{
  case kWindow:
  {
			vstWindow      = value;    
			ap->vstWindow  = value;           
			window          = (long) floor(128*vstWindow);
   spectralTransformer.setWindow(window);  
  }break;
  case kOverlapWindow:
  {
			vstOverlapWindow      = value;    
			ap->vstOverlapWindow  = value;           
			overlapWindow          = (long) floor(128*vstOverlapWindow);
   spectralTransformer.setOverlapWindow(overlapWindow);  
  }break;
  case kBlockSize:
  {
			vstBlockSize      = value;    
			ap->vstBlockSize  = value;      
   tmp               = floor(10*vstBlockSize)+3;
   tmp               = pow(2, tmp);
			blockSize         = (long) tmp;
   spectralTransformer.setBlockSize(blockSize);  
   setInitialDelay(blockSize);
  }break;
  case kContrastL:
  {
			vstContrastL      = value;    
			ap->vstContrastL  = value;           
			contrastL          = 2*vstContrastL-1;
			contrastL          = pow(4,contrastL);
   spectralTransformer.setContrastL(contrastL);  
  }break;
  case kContrastR:
  {
			vstContrastR      = value;    
			ap->vstContrastR  = value;           
			contrastR          = 2*vstContrastR-1;
			contrastR          = pow(4,contrastR);
   spectralTransformer.setContrastR(contrastR);  
  }break;

  case kMagMixL:
  {
			vstMagMixL      = value;    
			ap->vstMagMixL  = value;           
			magMixL         = vstMagMixL;
   spectralTransformer.setMagMixL(magMixL);  
  }break;
  case kMagMixR:
  {
			vstMagMixR      = value;    
			ap->vstMagMixR  = value;           
			magMixR         = vstMagMixR;
   spectralTransformer.setMagMixR(magMixR);  
  }break;
  case kPhsMixL:
  {
			vstPhsMixL      = value;    
			ap->vstPhsMixL  = value;           
			phsMixL         = vstPhsMixL;
   spectralTransformer.setPhsMixL(phsMixL);  
  }break;
  case kPhsMixR:
  {
			vstPhsMixR      = value;    
			ap->vstPhsMixR  = value;           
			phsMixR         = vstPhsMixR;
   spectralTransformer.setPhsMixR(phsMixR);  
  }break;





 }//end of switch


 //update the display in the default standard gui:
	updateDisplay();

 //
 if(editor)
  editor->postUpdate();

 //update the display in the Editor-GUI:
 if(editor)
  ((AEffGUIEditor*)editor)->setParameter (index, value);
}

//-----------------------------------------------------------------------------------------
//returns a parameter to the host:
float SpectralTransformerVST::getParameter(long index) 
{
	float v=0;
	switch(index)
	{
  case kWindow:           v = vstWindow;           break;
  case kOverlapWindow:    v = vstOverlapWindow;    break;
  case kBlockSize:        v = vstBlockSize;        break;
  case kContrastL:        v = vstContrastL;        break;
  case kContrastR:        v = vstContrastR;        break;
  case kMagMixL:          v = vstMagMixL;          break;
  case kMagMixR:          v = vstMagMixR;          break;
  case kPhsMixL:          v = vstPhsMixL;          break;
  case kPhsMixR:          v = vstPhsMixR;          break;
	}
	return v;
}

//-----------------------------------------------------------------------------------------
//tells the host, how it should name the parameters:
void SpectralTransformerVST::getParameterName(long index, char *label)
{
	switch(index)
	{
		case kWindow:           strcpy(label, "Window");             break;
		case kOverlapWindow:    strcpy(label, "OL-Window");          break;
		case kBlockSize:        strcpy(label, "BlockSize");          break;

		case kMono:             strcpy(label, "MonoIn");             break;
		case kNormMode:         strcpy(label, "NormMode");           break;
		case kDryWet:           strcpy(label, "DryWet");             break;
		case kVol:              strcpy(label, "Vol");                break;

		case kLifterOnOff:      strcpy(label, "LifterOn");           break;
		case kLifterLink:       strcpy(label, "LifterLink");         break;
		case kLifterModeL:      strcpy(label, "LifterModeL");        break;
		case kLifterModeR:      strcpy(label, "LifterModeR");        break;
		case kLifterQuefrencyL: strcpy(label, "LifterQuefrencyL");   break;

		case kScaleOnOff:      strcpy(label, "ScaleOn");             break;
		case kScaleLink:       strcpy(label, "ScaleLink");           break;
		case kScaleL:          strcpy(label, "ScaleL");              break;
		case kScaleR:          strcpy(label, "ScaleR");              break;

		case kShiftOnOff:      strcpy(label, "ShiftOn");             break;
		case kShiftLink:       strcpy(label, "ShiftLink");           break;
		case kShiftL:          strcpy(label, "ShiftL");              break;
		case kShiftR:          strcpy(label, "ShiftR");              break;

		case kWarpOnOff:       strcpy(label, "WarpOn");              break;
		case kWarpMap:         strcpy(label, "WarpMap");             break;
		case kWarpLink:        strcpy(label, "WarpLink");            break;
		case kWarpL:           strcpy(label, "WarpL");               break;
		case kWarpR:           strcpy(label, "WarpR");               break;
 
		case kDenoiseOnOff:    strcpy(label, "DenoiseOn");           break;
		case kDenoiseLink:     strcpy(label, "DenoiseLink");         break;
		case kDenoiseL:        strcpy(label, "DenoiseL");            break;
		case kDenoiseR:        strcpy(label, "DenoiseR");            break;

		case kMoreNoiseOnOff:  strcpy(label, "MoreNoiseOn");         break;
		case kMoreNoiseLink:   strcpy(label, "MoreNoiseLink");       break;
		case kMoreNoiseL:      strcpy(label, "MoreNoiseL");          break;
		case kMoreNoiseR:      strcpy(label, "MoreNoiseR");          break;

  case kContrastOnOff:   strcpy(label, "ContrastOn");          break;		
  case kContrastLink:    strcpy(label, "ContrastLink");        break; 
  case kContrastL:       strcpy(label, "ContrastL");           break;
		case kContrastR:       strcpy(label, "ContrastR");           break;

  case kPhaseTrimOnOff:  strcpy(label, "PhaseTrimOn");         break;		
  case kPhaseTrimLink:   strcpy(label, "PhaseTrimLink");       break; 
  case kPhaseTrimL:      strcpy(label, "PhaseTrimL");          break;
		case kPhaseTrimR:      strcpy(label, "PhaseTrimR");          break;

  case kPhaseRandOnOff:  strcpy(label, "PhaseRandOn");         break;		
  case kPhaseRandLink:   strcpy(label, "PhaseRandLink");       break; 
  case kPhaseRandL:      strcpy(label, "PhaseRandL");          break;
		case kPhaseRandR:      strcpy(label, "PhaseRandR");          break;

  case kFilterOnOff:     strcpy(label, "FilterOn");            break;		
  case kFilterLink:      strcpy(label, "FilterLink");          break; 
  case kFilterParL:      strcpy(label, "FilterParL");          break;
		case kFilterParR:      strcpy(label, "FilterParR");          break;
  case kFilterLpfL:      strcpy(label, "FilterLpfL");          break;
		case kFilterLpfR:      strcpy(label, "FilterLpfR");          break;
  case kFilterHpfL:      strcpy(label, "FilterHpfL");          break;
		case kFilterHpfR:      strcpy(label, "FilterHpfR");          break;

		case kMagMixL:          strcpy(label, "MagMixL");            break;
		case kMagMixR:          strcpy(label, "MagMixR");            break;
		case kPhsMixL:          strcpy(label, "PhsMixL");            break;
		case kPhsMixR:          strcpy(label, "PhsMixR");            break;

		case kMultiplyMags:     strcpy(label, "MultiplyMags");       break;

	}
}

//-----------------------------------------------------------------------------------------
//tells the host, how it should present the parameter-values (which are raw values
//between 0 and 1) to the user:
void SpectralTransformerVST::getParameterDisplay(long index, char *text)
{
	switch(index)
	{
		case kWindow:          float2string( (float) window,            text);      break;
		case kOverlapWindow:   float2string( (float) overlapWindow,     text);      break;
		case kBlockSize:       float2string( (float) blockSize,         text);      break;
		case kContrastL:       float2string( (float) contrastL,         text);      break;
		case kContrastR:       float2string( (float) contrastR,         text);      break;
		case kMagMixL:         float2string( (float) magMixL,           text);      break;
		case kMagMixR:         float2string( (float) magMixR,           text);      break;
		case kPhsMixL:         float2string( (float) phsMixL,           text);      break;
		case kPhsMixR:         float2string( (float) phsMixR,           text);      break;
	}//end switch
}

//-----------------------------------------------------------------------------------------
//tells the host, in which unit the parameter is displayed:
void SpectralTransformerVST::getParameterLabel(long index, char *label)
{
	switch(index)
	{
		case kWindow:           strcpy(label, "");         break;
		case kOverlapWindow:    strcpy(label, "");         break;
		case kBlockSize:        strcpy(label, "samples");  break;
		case kContrastL:        strcpy(label, "");         break;
		case kContrastR:        strcpy(label, "");         break;
		case kMagMixL:          strcpy(label, "amount R"); break;
		case kMagMixR:          strcpy(label, "amount R"); break;
		case kPhsMixL:          strcpy(label, "amount R"); break;
		case kPhsMixR:          strcpy(label, "amount R"); break;
	}
}

//-----------------------------------------------------------------------------------------
//the actual audio-process:
void SpectralTransformerVST::process(float **inputs, float **outputs, long sampleFrames)
{
	float *in1  =  inputs[0];
	float *in2  =  inputs[1];
	float *out1 = outputs[0];
	float *out2 = outputs[1];

 //the audio-loop, here is the place, where the dsp has to be implemented:
 for(int i=0; i<sampleFrames; i++)
 {
  spectralTransformer.getSamples(in1, in2, out1, out2);

  in1++;in2++;out1++;out2++; //increment pointers    
 }//end of for-loop

}//end process

//-----------------------------------------------------------------------------------------
//this function may be called by the host, when the effect is used as insert effect
void SpectralTransformerVST::processReplacing(float **inputs, float **outputs, long sampleFrames)
{
 SpectralTransformerVST::process(inputs, outputs, sampleFrames);
	//mostly both functions will have the same output - one could copy and paste the code from
	//prcess or simply call the function (copy & paste saves one function-call per buffer, so the
	//performance is not really affected (at least i think so)
}



//------------------------------------------------------------------------------------------
//this function is called, when the user deactivates/bypasses the plugIn in the host
//it is a good idea to flush the internal buffers of the effect here (if any)
//for example: a delay-line could set its circular buffer to all zeros
void SpectralTransformerVST::suspend()
{    

}

//------------------------------------------------------------------------------------------
//this function is called, when the user rectivates the plugIn (turns the bypass button off):
void SpectralTransformerVST::resume()
{
 AudioEffectX::resume();
 wantEvents();
}

//-----------------------------------------------------------------------------------------
//name of the effect (max 32 characters):
bool SpectralTransformerVST::getEffectName (char* name)
{
 strcpy (name, "SpectralTransformer");
 return true;
}

//-----------------------------------------------------------------------------------------
//name of the vendor (max 64 characters):
bool SpectralTransformerVST::getVendorString (char* text)
{
 strcpy (text, "Braindoc");
 return true;
}

//-----------------------------------------------------------------------------------------
//name of the product (max 64 characters):
bool SpectralTransformerVST::getProductString (char* text)
{
 strcpy (text, "SpectralTransformer");
 return true;
}

//-----------------------------------------------------------------------------------------
// see 'plugCanDos' in audioeffectx.cpp. return values:
// 0: don't know (default), 1: yes, -1: no
long SpectralTransformerVST::canDo (char* text)
{
	/*
 if (!strcmp (text, "receiveVstEvents"))
  return 1;
 if (!strcmp (text, "receiveVstMidiEvent"))
  return 1;
	*/
 return 0; // -1: explicitly can't do; 0 => don't know (default)
}

//-----------------------------------------------------------------------------------------
//tell host, how long it takes for the output of the plugIn to die out to zero, when silence
//comes in - host can decide to not call process/processReplacing when it knows that the output
//of the pluIn will be zero
long SpectralTransformerVST::getGetTailSize()
{
	return 0;  //    0: Not supported, continuous calls to the process methods are required. 
            //    1: No tail at all. 
            //other: The duration, in samples, the plug needs to 'sound out'.  
}


//from here: handling of programs (sets of parameters):
//-----------------------------------------------------------------------------------------
bool SpectralTransformerVST::getProgramNameIndexed (long category, long index, char* text)
{
 if (index < kNumPrograms)
 {
  strcpy (text, programs[index].name);
  return true;
 }
 return false;
}
//-----------------------------------------------------------------------------------------
bool SpectralTransformerVST::copyProgram (long destination)
{
 if (destination < kNumPrograms)
 {
  programs[destination] = programs[curProgram];
  return true;
 }
 return false;
}

//-----------------------------------------------------------------------------------------
//let host change the name of the current program:
void SpectralTransformerVST::setProgramName(char *name)
{
	strcpy (programs[curProgram].name, name);
}

//-----------------------------------------------------------------------------------------
//tell name of current program to host:
void SpectralTransformerVST::getProgramName(char *name)
{
	strcpy (name, programs[curProgram].name);
}

//-----------------------------------------------------------------------------------------
void SpectralTransformerVST::setProgram (long program)
{
 SpectralTransformerVSTProgram *ap = &programs[program];
 curProgram = program;

	setParameter(kWindow,          ap->vstWindow);
	setParameter(kOverlapWindow,   ap->vstWindow);
	setParameter(kBlockSize,       ap->vstBlockSize);
	setParameter(kContrastL,       ap->vstContrastL);
	setParameter(kContrastR,       ap->vstContrastR);
	setParameter(kMagMixL,         ap->vstMagMixL);
	setParameter(kMagMixR,         ap->vstMagMixR);
	setParameter(kPhsMixL,         ap->vstPhsMixL);
	setParameter(kPhsMixR,         ap->vstPhsMixR);

}

//-----------------------------------------------------------------------------------------
//from here: implementation of the SpectralTransformerVSTProgram class
SpectralTransformerVSTProgram::SpectralTransformerVSTProgram()
{
	//init parameters:
	//vstFiltMode  = 0.0;


	strcpy (name, "Init");
}

SpectralTransformerVSTProgram::~SpectralTransformerVSTProgram()
{

}