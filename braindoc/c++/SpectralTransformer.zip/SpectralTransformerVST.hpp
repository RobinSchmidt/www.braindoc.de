/*-----------------------------------------------------------------------------

� Braindoc 2002 (www.braindoc.de)


-----------------------------------------------------------------------------*/
#ifndef __Delay_H
#define __Delay_H

#include "..\VST-SDK\audioeffectx.h"

#include "VSTools.h"
#include "SpectralTransformer.h"
#include "SpectralTransformerVSTEditor.h"

const short kNumPrograms = 8;  //number of programs

enum
{
 kWindow,
 kOverlapWindow,
 kBlockSize,

 kMono,              //indicate, if input is mono
 kNormMode,          //normalization mode
 kDryWet,
 kVol,

 kLifterOnOff,
 kLifterLink,
 kLifterModeL,        //choose early of late pass lifters
 kLifterModeR,
 kLifterQuefrencyL,   //cutoff quefrencies of the lifters
 kLifterQuefrencyR,

 kFmtScaleOnOff,

 kScaleOnOff,
 kScaleLink,
 kScaleL,
 kScaleR,

 kShiftOnOff,
 kShiftLink,
 kShiftL,
 kShiftR,

 kWarpOnOff,
 kWarpMap,
 kWarpLink,
 kWarpL,
 kWarpR,

 kDenoiseOnOff,
 kDenoiseLink,
 kDenoiseL,
 kDenoiseR,

 kMoreNoiseOnOff,
 kMoreNoiseLink,
 kMoreNoiseL,
 kMoreNoiseR,

 kContrastOnOff,
 kContrastLink,
 kContrastL,
 kContrastR,

 kPhaseTrimOnOff,
 kPhaseTrimLink,
 kPhaseTrimL,
 kPhaseTrimR,

 kPhaseRandOnOff,
 kPhaseRandLink,
 kPhaseRandL,
 kPhaseRandR,

 kFilterOnOff,
 kFilterLink,
 kFilterParL,  //switch to parallel mode
 kFilterParR,
 kFilterLpfL,
 kFilterLpfR,
 kFilterHpfL,
 kFilterHpfR,

 kMagMixOnOff,
 kMagMixL,           //
 kMagMixR,

 kPhaseMixOnOff,
 kPhsMixL,
 kPhsMixR,

 kMultiplyMags, //multiply magnitudes (for vocoding)

	kNumParams           //this value now contains the number of parameters 
	                     //(as enums begin to count at 1)
};

//this is a class to store the parameter values of the plugIn (for saving presets, etc.
class SpectralTransformerVSTProgram  
{
friend class SpectralTransformerVST;

public:
	SpectralTransformerVSTProgram();
	virtual ~SpectralTransformerVSTProgram();

	//declare plug-in's parameters (values between 0 and 1):
 float vstWindow, vstOverlapWindow, vstBlockSize,
       vstContrastL, vstContrastR,
       vstMagMixL, vstMagMixR,
       vstPhsMixL, vstPhsMixR;

 char name[24];
};

//this is the class for the actual PlugIn object:
class SpectralTransformerVST : public AudioEffectX
{
public:
	//constructor/destructor:
	SpectralTransformerVST(audioMasterCallback audioMaster);
	~SpectralTransformerVST();

	//functions to override:
	//audio processing:
	virtual void  process         (float **inputs, float **outputs, long sampleFrames);
	virtual void  processReplacing(float **inputs, float **outputs, long sampleFrames);

 //event processing:
 //virtual long  processEvents   (VstEvents* events);
	virtual void  suspend         ();
 virtual void  resume          ();

	//program handling:
	virtual void  setProgramName        (char *name);
	virtual void  getProgramName        (char *name);
	virtual void  setProgram            (long program);
 virtual bool  copyProgram           (long destination);
 virtual bool  getProgramNameIndexed (long category, long index, char* text);

	//parameter handling:
	virtual void  setSampleRate      (float sampleRate);
	virtual void  setParameter       (long  index, float value);
	virtual float getParameter       (long  index);
	virtual void  getParameterLabel  (long  index, char *label);
	virtual void  getParameterDisplay(long  index, char *text);
	virtual void  getParameterName   (long  index, char *text);

	//tell host some features (if host asks):
	virtual bool  getEffectName    (char* name);
	virtual bool  getVendorString  (char* text);
	virtual bool  getProductString (char* text);
	virtual long  canDo            (char* text);
	virtual long  getGetTailSize   ();

	//new member functions:


protected:
	//declare plug-in's parameters (values between 0 and 1):
 float vstWindow, vstOverlapWindow, vstBlockSize,
       vstContrastL, vstContrastR,
       vstMagMixL, vstMagMixR,
       vstPhsMixL, vstPhsMixR;

	char programName[32];

private:

 //new member functions:

	//declare plug-in's private member-variables:
	//mapped parameters for internal representation:
 long   window, overlapWindow, blockSize;
 sample contrastL, contrastR,
        magMixL, magMixR, phsMixL, phsMixR;


	SpectralTransformerVSTProgram *programs; //array of stored parameter sets

	SpectralTransformer spectralTransformer;        //this is the actual audio-processing module
};

#endif
