/* 

WindowMaker.h: interface for the WindowMaker class.

� Braindoc 2006 (www.braindoc.de)

This class generates window functions for use with FFT-based effects, for example.

*/

#if !defined(WindowMaker_h_Included)
#define WindowMaker_h_Included

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "VSTools.h"

class WindowMaker  
{
public:
	WindowMaker();
	virtual ~WindowMaker();

 //fill the "Buffer with various windows:
 void getRectangularWindow(sample *Buffer, long Length); 
 void getTriangularWindow (sample *Buffer, long Length);                                                     
 void getCosSquaredWindow (sample *Buffer, long Length);  

};

#endif // !defined(WindowMaker_h_Included)
