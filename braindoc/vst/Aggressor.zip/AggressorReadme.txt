known bugs:
 -some menus do not update properly when loading a song
 -on the overview screen, sometimes the menus don't work

what's new (compared to the old "Demo" version):
 -better oscillator quality (anti-aliasing)
 -random detuning for the unison-mode in osc1
 -allpass-filters (apf's) for all the oscillators
 -adjustable DC-offset before the filter (makes sense only for the nonlinear moog- and 303-filters)
 -osc3 parameters are now available (they were formerly hidden as demo-restriction)
 -oscillators switch into free-running mode when the start-phase parameter is in the rightmost position

troubleshooting:
 -if you did a song or a preset with an older version of aggressor, and the preset sounds different now, make sure that the new parameters are set to their neutral position (osc-apf's, filter-DC, ...) - some hosts initialize these to their leftmost position. in most hosts a ctrl-click resets the parameter.

