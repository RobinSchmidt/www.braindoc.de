clear all;

%--------------------------------------------------------------------------
%specify the algorithms parameters:
f            = 110;      %fundamental frequency
bw           = 20;       %bandwidth of the fundamental in cents
numHarmonics = 50;       %number of harmonics, has to be < sampleRate/f
bwScale      = 0.80;     %dependency of the bandwidth on the harmonic number (0:const, 1:linear, >1: more than linear)        
tiltExp      = 1.00;     %introduces inharmonicity when !=1 (<1: overtone-frequencies lower that number*f; >1:higher)
distExp      = 2.00;     %exponent for the frequency distribution (1: exponential, 2: gaussian; >2: lower tails)

%specify the output-format:
N            = 262144;      %size of the wave table to be generated
sampleRate   = 44100;       %the sample-rate
bitDepth     = 24;          %bit-depth for the output wave-file
fileName     = strcat('PadSynth_', sprintf('%.0f',f), '_', sprintf('%.0f',bw), '_', ...,
                      sprintf('%.0f',numHarmonics), '_', sprintf('%.2f',bwScale), ...,
                      '_', sprintf('%0.2f', tiltExp), '_', sprintf('%.2f', distExp), '.wav' );

%--------------------------------------------------------------------------
%generate the array for the amplitudes of the harmonics (the A-array):
A = ones(numHarmonics,1);


% %let only harmonics pass which are octaves to the fundamental (organ-like sound):
% for k=1:numHarmonics
%  if( (log2(k)-round(log2(k))) == 0)
%   A(k,1) = 1;
%  else
%   A(k,1) = 0;
%  end 
% end


%--------------------------------------------------------------------------
%implementation of the actual spectral synthesis algorithm:

%allocate arrays for the amplitudes of and phases for each frequency bin
%and initialize with zeros:
freq_amp = zeros(N/2, 1);
freq_phs = zeros(N/2, 1);

%generate the array for the amplitudes:
for nh=1:numHarmonics
 f_Hz     = f*relF(nh, tiltExp);
 bw_Hz    = (2^(bw/1200) - 1.0) * f * (relF(nh,tiltExp))^bwScale;
 freq_amp = freq_amp + A(nh,1)*generalizedFreqDistribution(f_Hz, bw_Hz, sampleRate, (N/2), distExp);
end
%generate the table for the phases:
for k=1:(N/2)
 freq_phs(k,1) = rand(1,1)*2*pi; 
end

%--------------------------------------------------------------------------
%generate of the signal from the spectral envelope:

%convert from the magnitude/phase representation to the real/imaginary
%representation:
re = zeros(N/2,1);
im = zeros(N/2,1);
for k=1:(N/2)
 re(k,1) = freq_amp(k,1) * cos(freq_phs(k,1));
 im(k,1) = freq_amp(k,1) * sin(freq_phs(k,1));
end

%combine the real and imaginary part to the complex fourier spectrum (where
%the real part has odd and the imaginary part has even symmetry):
spectrum = zeros(N,1);
for k = 1:(N/2)
 spectrum(k,1) = re(k,1) + i * im(k,1); 
end
for k = 1:(N/2)
 spectrum((N/2)+k,1) = conj(spectrum((N/2)-k+2)); 
end

%calculate the time domain signal by means of an IFFT:
signal = ifft(spectrum);

%take only the real part (the imaginary part should be theoretically zero,
%but because of numerical inaccuracies it isn't):
signal = real(signal);

%normalize the signal:
signal = signal./max(signal);

%write the signal into a wave-file
wavwrite(signal, sampleRate, bitDepth, fileName);

%play the signal:
sound(signal, sampleRate);