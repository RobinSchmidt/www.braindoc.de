function [binAmps] = gaussianFreqDistribution(centerFreq, bandWidth, sampleRate, blockSize)

%retruns a vector with values of the gaussian frequency ditribution

% %for testing only:
% clear all;
% centerFreq = 440;
% bandWidth  = 100;
% sampleRate = 44100;
% blockSize  = 2048;

%calculate vector with the bin-frequencies:
binFreqs   = 0:1:(blockSize-1);
binFreqs   = binFreqs.*(0.5*sampleRate/blockSize);
binFreqs   = binFreqs';

%init amplitudes with the frequency-value minus the center freq:
binAmps    = binFreqs-centerFreq;
%take the square:
binAmps    = binAmps.^2;
%take the exp of the negative value (to make it gaussian) and normalize by the bandwidth:
binAmps    = exp(-binAmps/(2*bandWidth*bandWidth))./bandWidth;

