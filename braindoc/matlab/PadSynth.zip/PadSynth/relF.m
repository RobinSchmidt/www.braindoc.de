function result = relF(N, tiltExponent);
result = N^tiltExponent;