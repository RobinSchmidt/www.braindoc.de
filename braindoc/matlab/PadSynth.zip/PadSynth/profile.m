function result = profile(fi, bwi)

x      = fi/bwi;
result = exp(-x*x)/bwi;