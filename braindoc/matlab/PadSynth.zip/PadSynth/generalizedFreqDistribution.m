function [binAmps] = generalizedFreqDistribution(centerFreq, bandWidth, sampleRate, blockSize, exponent)

%retruns a vector with values of generalized frequency ditribution

%calculate vector with the bin-frequencies:
binFreqs   = 0:1:(blockSize-1);
binFreqs   = binFreqs.*(0.5*sampleRate/blockSize);
binFreqs   = binFreqs';

%init amplitudes with the frequency-value minus the center freq:
binAmps    = binFreqs-centerFreq;

%take the absolut value and raise the result to some power:
binAmps    = abs(binAmps).^exponent;

%take the exp of the negative value (to make it gaussian) and normalize by the bandwidth:
binAmps    = exp(-binAmps/(2*bandWidth^exponent))./bandWidth;

