// To generate the resource file "DelayEdit.rsrc", do:
// mwbres -o DelayEdit.rsrc DelayEdit.r

resource('RAWT', 128, "bmp00128.bmp") {
	read("bmp00128.bmp")
}
resource('RAWT', 129, "bmp00129.bmp") {
	read("bmp00129.bmp")
}
resource('RAWT', 130, "bmp00130.bmp") {
	read("bmp00130.bmp")
}
