/*-----------------------------------------------------------------------------

� 1999, Steinberg Soft und Hardware GmbH, All Rights Reserved

-----------------------------------------------------------------------------*/
#include "ADelayEdit.hpp"

#ifndef __ADEditor
#include "ADEditor.hpp"
#endif

#include <string.h>

extern bool oome;

//-----------------------------------------------------------------------------
ADelayEdit::ADelayEdit (audioMasterCallback audioMaster)
 : ADelay (audioMaster)
{
	setUniqueID ('ADlE');
	editor = new ADEditor (this);
	if (!editor)
		oome = true;
}

//-----------------------------------------------------------------------------
ADelayEdit::~ADelayEdit ()
{
	// the editor gets deleted by the
	// AudioEffect base class
}

//-----------------------------------------------------------------------------
void ADelayEdit::setParameter (long index, float value)
{
	ADelay::setParameter (index, value);

	if (editor)
		((AEffGUIEditor*)editor)->setParameter (index, value);
}
