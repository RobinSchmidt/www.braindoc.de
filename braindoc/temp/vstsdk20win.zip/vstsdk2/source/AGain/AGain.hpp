/*-----------------------------------------------------------------------------

� 1999, Steinberg Soft und Hardware GmbH, All Rights Reserved

-----------------------------------------------------------------------------*/
#ifndef __AGAIN_H
#define __AGAIN_H

#include "audioeffectx.h"

class AGain : public AudioEffectX
{
public:
	AGain(audioMasterCallback audioMaster);
	~AGain();

	virtual void process(float **inputs, float **outputs, long sampleFrames);
	virtual void processReplacing(float **inputs, float **outputs, long sampleFrames);
	virtual void setProgramName(char *name);
	virtual void getProgramName(char *name);
	virtual void setParameter(long index, float value);
	virtual float getParameter(long index);
	virtual void getParameterLabel(long index, char *label);
	virtual void getParameterDisplay(long index, char *text);
	virtual void getParameterName(long index, char *text);

protected:
	float fGain;
	char programName[32];
};

#endif
